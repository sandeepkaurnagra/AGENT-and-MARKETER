﻿
<?php ob_start();
include('../include/admin-header.php');
include('../include/connection.php');
 ?>


  <main id="main">
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Update Marketer</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Update Marketer</li>
          </ol>
        </div>

      </div>
    </section>
	<?php
if(isset($_POST['btn_submit']))
{ 
$fname=trim($_POST['first_name']);
    $lname=trim($_POST['last_name']);
   $id=trim($_POST['id']);
    $department=trim($_POST['department']);
	$uname=trim($_POST['user_name']);
    $pass=$_POST['user_password'];
    $repass=$_POST['confirm_password'];
	$email=trim($_POST['email']);
    $contact=trim($_POST['contact_no']);

		$flag=0;
    if($fname && $lname && $email && $contact)
    {
        if($pass==$repass)
        {
			$str="update marketer_register set fname='$fname',lname='$lname',purpose='$department',username='$uname',password='$pass',email='$email',contact='$contact' where id='$id'";
         header('Refresh: 3;url=viewmarketer.php');
        if(mysqli_query($connect,$str))
        {
            echo '<div class="alert alert-success">Marketer Updation Done Successfully. </div>';
        }
        else
        {
            echo '<div class="alert alert-danger">Error Occured.' . $str .' <br>' . mysqli_error($connect).'</div>';
        }
        }
        else
        {
            echo '<div class="alert alert-danger">Password and Retype Password Mismatch</div>';
        }
    }
	 else
                            {
                                echo '<div class="alert alert-danger">All Fields Required.</div>';
                            }
}
?>
	
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
        <div class="container">

            <form class="well form-horizontal"  action="updatemarketer.php" method="post" id="contact_form">
                <fieldset>
<center><h2><b>Update Marketer Detail</b></h2></center>
                   <?php
                            
if(isset($_GET['id']))
                          {
                            $id=$_GET['id'];
								$query=mysqli_query($connect,"select * from marketer_register where id='$id'");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
                        <!-- Text input-->
                        <div class="col-md-10 register-form">
                            <div class="modal-content">
                                <div class="form-group">
								<input name="id" value="<?php echo $row['id']; ?>" type="hidden" required>
                                    
                                    <label class="col-md-12 control-label">First Name</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-user"></i></span>
                                            <input name="first_name" value="<?php echo $row['fname']; ?>" placeholder="First Name" class="form-control" type="text" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Text input-->

                                <div class="form-group">
                                    <label class="col-md-12 control-label">Last Name</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-user"></i></span>
                                            <input name="last_name" value="<?php echo $row['lname']; ?>" placeholder="Last Name" class="form-control" type="text" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-12 control-label">Purpose of use</label>
                                    <div class="col-md-12 selectContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-list"></i></span>
                                            <select name="department" class="form-control selectpicker" required>
                                                <option value="<?php echo $row['purpose']; ?>"><?php echo $row['purpose']; ?></option>
                                                <option>Inter Official Use</option>
                                                <option>Intra Official Use</option>
                                               
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Text input-->

                                <div class="form-group">
                                    <label class="col-md-12 control-label">Username</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-user"></i></span>
                                            <input name="user_name" value="<?php echo $row['username']; ?>" placeholder="Username" class="form-control" type="text" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Text input-->

                                <div class="form-group">
                                    <label class="col-md-12 control-label">Password</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-lock"></i></span>
                                            <input name="user_password" value="<?php echo $row['password']; ?>" placeholder="Password" class="form-control" type="password" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Text input-->

                                <div class="form-group">
                                    <label class="col-md-12 control-label">Confirm Password</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-lock"></i></span>
                                            <input name="confirm_password" value="<?php echo $row['password']; ?>" placeholder="Confirm Password" class="form-control" type="password" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="col-md-12 control-label">E-Mail</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-envelope"></i></span>
                                            <input name="email" value="<?php echo $row['email']; ?>" placeholder="E-Mail Address" class="form-control" type="email" required>
                                        </div>
                                    </div>
                                </div>


                                <!-- Text input-->

                                <div class="form-group">
                                    <label class="col-md-12 control-label">Contact No.</label>
                                    <div class="col-md-12 inputGroupContainer">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="icofont-phone"></i></span>

                                            <input name="contact_no" placeholder="(+61)" value="<?php echo $row['contact']; ?>" class="form-control" type="text" required>
                                        </div>
                                    </div>
                                </div>

                                 <?php
                                           }   
                                      }
						  }									  
                                      ?>
                                <div class="form-group">
                                    <label class="col-md-12 control-label"></label>
                                    <center>
                                        <div class="col-md-4">
                                            <button type="submit" name="btn_submit" class="btn btn-link">
                                                SUBMIT <span class="glyphicon glyphicon-send"></span>
                                            </button>
                                        </div>
                                    </center>
                                </div>
                            </div>
                    </div>
</fieldset>
            </form>
        </div>
        </div><!-- /.container -->
    </section><!-- End Services Section -->

    
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
   <?php 
include('../include/admin-footer.php');
 ?>