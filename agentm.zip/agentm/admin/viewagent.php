<?php ob_start();
include('../include/admin-header.php');
include('../include/connection.php');
 ?>
<section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>View Agent</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>View Agent</li>
          </ol>
        </div>

      </div>
    </section>
      
    <section id="contact" class="contact">
	
	<?php
                          if(isset($_GET['id']))
                          {
                            
                            $query_delete=mysqli_query($connect,"delete from agent_register where id='".$_GET['id']."'");
                            if(mysqli_affected_rows($connect)>0)
                            {
                                echo '<script>
                                alert("Agent Information Deleted Successfully.");
                              var windowlocation = window.location.href.split("?")[0];
                               window.location.href =windowlocation;
                                </script>';
                            }
                          }
                           ?>
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>View Agent</h2>
        </div>
		
			<div class="col-md-12 contact-grid wow fadeInUp animated" data-wow-delay=".5s">
			
     <table id="example" class="table table-striped table-bordered" style="width:100%">
                                      <thead>
                                      <tr>
                                          <th>ID</th>
                                          <th>First Name</th>
                                         
                                          <th >Last Name</th>
                                          <th >Purpose</th>
										  <th>Username</th>
										  <th>Password</th>
										  <th>Email</th>
										<th>Contact</th>
										<th>Action1</th>
										<th>Action2</th>
                                      </tr>
                                      </thead>
                                      <tbody>
                                      <?php
                                      $query=mysqli_query($connect,"select * from agent_register");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
                                              <tr class="gradeX">
                                                  <td><?php echo $row['id']; ?></td>
                                                  <td><?php echo $row['fname']; ?></td>
                                                
                                                  <td><?php echo $row['lname']; ?></td>
                                                  <td><?php echo $row['purpose']; ?></td>
                                                  <td><?php echo $row['username']; ?></td>
												  <td><?php echo $row['password']; ?></td>
												   <td><?php echo $row['email']; ?></td>
												     <td><?php echo $row['contact']; ?></td>
                                                  <td><a href="updateagent.php?id=<?php echo $row['id'] ?>" class="btn btn-primary btn-xs">Update</a></td><td>
												  <a href="viewagent.php?id=<?php echo $row['id'] ?>" class="btn btn-danger btn-xs">Delete</a>
												  </td>
                                                 
                                              </tr>
                                                
                                                <?php
                                           }   
                                      } 
                                      ?>
                                      </tbody>
                                      
                          </table>
                               </div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>
      <!--main content end-->
<?php 
include('../include/admin-footer.php');
 ?>
