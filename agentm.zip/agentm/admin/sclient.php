<?php ob_start();
include('../include/admin-header.php');
include('../include/connection.php');
 ?>
<section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>View Subscribers</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>View Subscribers</li>
          </ol>
        </div>

      </div>
    </section>
      
    <section id="contact" class="contact">
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>View Subscribers</h2>
        </div>
		
			<div class="col-md-12 contact-grid wow fadeInUp animated" data-wow-delay=".5s">
			
 <table class="table table-bordered table-hover">
                                      <thead>
                                      <tr>
                                          <th>Client ID</th>
                                          <th>First Name</th>
                                         
                                          <th >Last Name</th>
                                          <th >Purpose</th>
										  <th>Username</th>
										  <th>Password</th>
										  <th>Email</th>
										<th>Contact</th>
                                      </tr>
                                      </thead>
                                      <tbody>
                                      <?php
                                      $query=mysqli_query($connect,"select * from client_register");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
                                              <tr class="gradeX">
                                                  <td><?php echo $row['id']; ?></td>
                                                  <td><?php echo $row['fname']; ?></td>
                                                
                                                  <td><?php echo $row['lname']; ?></td>
                                                  <td><?php echo $row['purpose']; ?></td>
                                                  <td><?php echo $row['username']; ?></td>
												  <td><?php echo $row['password']; ?></td>
                                                     <td><?php echo $row['email']; ?></td>
 <td><?php echo $row['contact']; ?></td>													 
                                              </tr>
                                                
                                                <?php
                                           }   
                                      } 
                                      ?>
                                      </tbody>
                                      <tfoot>
                                      <tr>
<th>Client ID</th>
                                          <th>First Name</th>
                                         
                                          <th >Last Name</th>
                                          <th >Purpose</th>
										  <th>Username</th>
										  <th>Password</th>
										  <th>Email</th>
										<th>Contact</th>
                                      </tr>
                                      </tfoot>
                          </table>
                               </div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>
      <!--main content end-->
<?php 
include('../include/admin-footer.php');
 ?>
