<?php ob_start();
include('../include/admin-header.php');
include('../include/connection.php');
 ?>
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Profile Update</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Profile Update</li>
          </ol>
        </div>

      </div>
    </section>
<section id="contact" class="contact">
	<div class="container">
	
	

			<div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-md-12">
		  <div class="section-title" data-aos="fade-up">
          <h2>Profile Update</h2>
        </div>
		  
               <?php
                              if(isset($_POST['submit4']))
                              {
                                   $old_pass=trim(md5($_POST['old_pass']));
                                   $pass=trim($_POST['pass']);
                                   $repass=trim($_POST['repass']);
                                   if(!empty($old_pass) && !empty($pass) && !empty($repass))
                                   {
									  // echo "select * from client_register where id='".$_SESSION['c_id']."'";
                                        $query=mysqli_query($connect,"select * from admin where name='admin'");
                                        if(mysqli_num_rows($query)>0)
                                        {
                                         $row=mysqli_fetch_assoc($query);
											
											//echo $row['password'];
                                            if($old_pass==$row['pass'])
                                            {
                                                if($pass==$repass)
													
												{ 
												$pass2=md5($pass);
                                                $qry="update admin set pass='$pass2' where name='admin'";
                                                    
                                                    if(mysqli_query($connect,$qry))
                                                    {
                                                        echo '<script>
                                                        alert("Admin Password Updated Successfully.");
                                                        window.location.href="logout.php";
                                                        </script>';
                                                        //header('Location:logout.php');
                                                    }
                                                    else
                                                    {
                                                        echo '<div class="alert alert-danger">Error Occured.</div>';
                                                    }
                                                }
                                                else
                                                {
                                                    echo '<div class="alert alert-danger">Password and ReType password mis-match.</div>';
                                                }
                                            }
                                            else
                                            {
                                                echo'<div class="alert alert-danger">Old Password is in-correct.</div>';
                                            }
                                        }
                                   }
                                   else
                                   {
                                    echo '<div class="alert alert-danger">All Field required.</div>';
                                   } 
                              }
                              
                               ?>
				<form method="post" class="modal-content">
					
					<div class="form-group">
					<input class="form-control" type="password" required="" name="old_pass" placeholder="Old Password"/>
					</div><div class=" form-group">
					<input class="form-control" type="password" required="" name="pass" placeholder="New Password" />
					</div><div class="form-group">
					<input class="form-control" type="password" required="" name="repass" placeholder="ReType Password" />
					</div><div class="form-group">
					<input class="form-control" style="background: #110f0a;color: #fff;" type="submit" value="Submit" name="submit4" >
				</div>
				</form>
			</div>
			
			
		
		</div>
	</div>
</section>

    <?php 
include('../include/admin-footer.php');
 ?>