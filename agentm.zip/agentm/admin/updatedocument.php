<?php ob_start();
include('include/marketer-header.php');
include('include/connection.php');
 ?>
 
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
        
          <h2>View Uploaded Documents</h2>
          <ol>
            <li><a href="dash2.php">Home</a></li>
            <li>View Uploaded Documents</li>
          </ol>
        </div>

      </div>
    </section>
 <!--Starting of Content-->
<section id="contact" class="contact">
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>View Uploaded Documents</h2>
        </div>
		
			<table id="example" class="table table-striped table-bordered" style="width:100%">
	
<thead>
                	<tr><th>Agent ID</th>
<th>Name</th>
<th>Document Title</th>
					<th>Document Description</th>
					<th>Attachment 1</th>
						<th>Attachment 2</th>
					<th>Email to</th>
               
				  <th>Action1</th>
				  <th>Action2</th>
				  <th>Action3</th>
				  <th>Action4</th></tr></thead><tbody>
    			
		<?php
		
		$query1=mysqli_query($connect,"SELECT * FROM marketer_register WHERE id='".$_SESSION['marketer_id']."'");
						$row2=mysqli_fetch_array($query1);
						$purpose=$row2['email'];
		$query=mysqli_query($connect,"select  * from document where email_to='$purpose'");
		
				           if(mysqli_num_rows($query)>0)
							{
								while($myrow=mysqli_fetch_array($query))
								{
							
		
				?>
			<tr>
                
    					<td><?php echo $myrow['agent_id']; ?></td>

        				<td><?php echo $myrow['name']; ?></td>
						<td><?php echo $myrow['doc_title']; ?></td>
						<td><?php echo $myrow['doc_desc']; ?></td>
						<?php if(empty($myrow['attachment1'])){ ?>
				<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment1']; ?>" target="_blank" />view file 1</a></td>
						<?php }?>
						
						<?php if(empty($myrow['attachment2'])){ ?>
				<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment2']; ?>" target="_blank" />view file 2</a></td>
						<?php }?>
						
						<td><?php echo $myrow['email_to']; ?></td>

	
 <td><a href="udocument.php?id=<?php echo $myrow['id'] ?>" class="btn btn-primary btn-xs">Update</a></td>
  <td><a href="udocument.php?id=<?php echo $myrow['id'] ?>" class="btn btn-info btn-xs">Delete</a></td>
 <td><a href="udocument.php?id=<?php echo $myrow['id'] ?>" class="btn btn-success btn-xs">Accept</a></td>
 <td><a href="udocument.php?id=<?php echo $myrow['id'] ?>" class="btn btn-danger btn-xs">Reject</a></td>
                                                
	
               </tr>
	
		
		<?php
								}
				
								}
					
			
				
		?>
		
		</tbody>
		</table>
		</div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>

    <?php 
include('include/agent-footer.php');

 ?>