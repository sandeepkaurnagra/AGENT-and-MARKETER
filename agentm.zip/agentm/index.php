 <?php ob_start();
 include('include/header.php');  
include('include/connection.php');  
?>
 <section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1  slide/slide-1-->
        <div class="carousel-item active" style="background-image: url(assets/img/h2.jpg);">
          <div class="container">
            <div class="carousel-content animated fadeInUp">
              <h2 class="text-center">Agent<span> Login</span></h2>
			                          <form action="" method="post" role="form">
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <span class="icofont-user"></span>
                                    </span>
                                    <input type="text" class="form-control" placeholder="User Name" name="username" required/>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <span class="icofont-lock"></span>
                                    </span>
                                    <input type="password" class="form-control" placeholder="Password" name="pass" required/>

                                </div>

                            </div>

                            <div class="form-group text-center">
                                <button type="submit" style="background:transparent;" name="btn_client" class="btn-get-started">Login</button>
                            </div>

                        </form>
                    
             <?php 
                         if(isset($_POST['btn_client']))
                        {
							
                            $email_login=trim($_POST['username']);
                            $pass_login=trim($_POST['pass']);
                            $query_login=mysqli_query($connect, "select * from agent_register where username='$email_login' and password='$pass_login'");
                            if(mysqli_num_rows($query_login)>0)
                             {
								  while($row_login=mysqli_fetch_array($query_login))
                                    {
										

                                $_SESSION['agent_id']=$row_login['id'];  
                              $_SESSION['agent_name']=$row_login['username'];   
                                echo '<script>
                                 alert("Login Successfully");
                                window.location.href="dash.php";
                                </script>';                                 
                                //$url=$_SERVER['REQUEST_URI'];
                                header("refresh:1;Location: dash.php"); 

			                    }
                            }
                             else
                             {
                                 echo '<script>
                                 alert("username and password mismatch.");
                                 </script>';
                            }
						}							
							
                        ?>
    
              <div class="text-left">Don't have an account&nbsp;!<a href="signup.php" class="">&nbsp;Signup Now</a></div>
            </div>
          </div>
        </div>

        

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon bx bx-left-arrow" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon bx bx-right-arrow" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
  </section><!-- End Hero -->

  <?php ob_start();
include('include/footer.php'); 

?>
