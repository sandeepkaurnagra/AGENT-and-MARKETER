<?php ob_start();
include('include/marketer-header.php');
include('include/connection.php');
 ?>


 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Marketer Panel</h2>
          <ol>
            <li><a href="dash2.php">Home</a></li>
            <li>Marketer Panel</li>
          </ol>
        </div>

      </div>
    </section>


 <section id="cta-pricing" class="cta-pricing">
      <div class="container">

        <div class="text-center">
          
          
        </div>
<div class="row">
<div class="col-md-8" style="text-align:center;border:2px groove red;">

    <div class="text-center">
	<h3 style="margin-top:100px;">Welcome <?php echo $_SESSION['marketer_name'];?></h3>
          <h3><a href="vmdocument.php" >Click to view Documents</a></h3>
          
        </div>
 

 
</div>
<div class="col-md-4" style="text-align:center">
<a href="squery.php" >
 <img src="assets/img/response.png"/>
 <p style="font-weight:bold;margin-top:20px;">Click to Response Query</p>
 </a>
</div>
</div>
      </div>
    </section>


<?php 
include('include/agent-footer.php');

 ?>
