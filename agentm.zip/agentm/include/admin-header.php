<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Agent and Marketer Admin Panel</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

 <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="../assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="../assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
<link href="../assets/css/font-awesome.css" rel="stylesheet" />
<link href="../assets/css/font-awesome.min.css" rel="stylesheet" />

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Top Bar ======= -->
 <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i><a href="mailto:sumitkumarkatharia@gmail.com">sumitkumarkatharia@gmail.com</a>
        <i class="icofont-phone"></i> +91 844 740 3460
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
 <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="index.php">Agent and Marketer Admin</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
         
         
         <li class="drop-down"><a href="#">Agent Operations</a>
                           <ul>
                          
                           <li><a href="viewagent.php">View Agents</a></li>
                           <li><a href="vmdocument.php">View Documents</a></li>
						   
                           </ul>
                            </li>
							 <li class="drop-down"><a href="#">Marketer Operations</a>
                           <ul>
                          
                           <li><a href="marketer-signup.php">Add Marketers</a></li>
                           <li><a href="viewmarketer.php">View Marketers</a></li>
						   
                           </ul>
                            </li>
                 <li class="drop-down"><a href="#">Query</a>
                           <ul>
                          
                           <li><a href="squery.php">View Queries</a></li>
                           </ul>
                            </li>
                           <li class="drop-down"><a href="#">Admin Panel</a>
                           <ul>
                          
                           <li><a href="profile.php">Setting</a></li>
                           <li><a href="logout.php">Logout</a></li>
                           </ul>
                            </li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->
