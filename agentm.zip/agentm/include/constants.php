<?php
//Database Constants
/*define("Db_Server","localhost");
define("Db_User","resort");
define("Db_Pass","ResOrt@91");
define("Db_Name","resort");*/
?>

<?php
//Database Constants
define("Db_Server","localhost");
define("Db_User","root");
define("Db_Pass","");
define("Db_Name","agentm");
?>
