<?php ob_start();
include('include/marketer-header.php');
include('include/connection.php');
 ?>
<section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Query Response</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Query Response</li>
          </ol>
        </div>

      </div>
    </section>
      
    <section id="contact" class="contact">
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>Query Response</h2>
        </div>
		
			<div class="col-md-12 contact-grid wow fadeInUp animated" data-wow-delay=".5s">
			
 <table id="example" class="table table-striped table-bordered" style="width:100%">
                                      <thead>
                                      <tr>
                                          <th>ID</th>
                                          <th>Agent ID</th>
											<th >Name</th> 
                                          <th >Query To</th>
                                          <th >Email</th>
										   <th>Attachment</th>
										  <th>Query</th>
										  <th>Response</th>
										  <th>Action</th>
										
                                      </tr>
                                      </thead>
                                      <tbody>
                                      <?php
									  $query1=mysqli_query($connect,"SELECT * FROM marketer_register WHERE id='".$_SESSION['marketer_id']."'");
						$row2=mysqli_fetch_array($query1);
						$email=$row2['email'];
                                      $query=mysqli_query($connect,"select * from query where email='$email' ");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($myrow=mysqli_fetch_array($query))
                                           {
                                                ?>
                                              <tr class="gradeX">
                                         <td><?php echo $myrow['id']; ?></td>         
    					<td><?php echo $myrow['cid']; ?></td>

        				<td><?php echo $myrow['name']; ?></td>
						<td><?php echo $myrow['queryto']; ?></td>
						<td><?php echo $myrow['email']; ?></td>
						<?php if(empty($myrow['attachment'])){ ?>
						<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment']; ?>" target="_blank" />view Attachment</a></td>
						<?php }?>
						<td><?php echo $myrow['msg']; ?></td>
<?php if(empty($myrow['response'])){ ?>
        				<td class="alert alert-warning">Not Respond Yet</td>
<?php } else{?>
	<td><?php echo $myrow['response'];  ?></td><?php }?>	
                                                  <td><a href="mrquery.php?stuid=<?php echo $myrow['id'] ?>" class="btn btn-primary btn-xs">Response Query</a></td>
                                                 
                                              </tr>
                                                
                                                <?php
                                           }   
                                      } 
                                      ?>
                                      </tbody>
                                      
                          </table>
                               </div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>
      <!--main content end-->
<?php 
include('include/agent-footer.php');
 ?>
