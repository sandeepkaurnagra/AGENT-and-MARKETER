<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');
 ?>
 
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
        
          <h2>View Uploaded Documents</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>View Uploaded Documents</li>
          </ol>
        </div>

      </div>
    </section>
 <!--Starting of Content-->
<section id="contact" class="contact">
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>View Uploaded Documents</h2>
        </div>
		
			<div class="col-md-12 contact-grid wow fadeInUp animated" data-wow-delay=".5s">
			

		
               		
    <table id="example" class="table table-striped table-bordered" style="width:100%">
	<thead>
                	<tr><th>Agent ID</th>
<th>Name</th>
<th>Document Title</th>
					<th>Document Description</th>
					<th>Attachment 1</th>
						<th>Attachment 2</th>
					<th>Email to</th>
                  <th>Marketer Response</th>
				  <th>Action</th>
				  </tr>
				  </thead>
    		<tbody>	
		<?php
		$query=mysqli_query($connect,"select  * from document where agent_id='".$_SESSION['agent_id']."'");
		
				           if(mysqli_num_rows($query)>0)
							{
								while($myrow=mysqli_fetch_array($query))
								{
							
		
				?>
			<tr>
                
    					<td><?php echo $myrow['agent_id']; ?></td>

        				<td><?php echo $myrow['name']; ?></td>
						<td><?php echo $myrow['doc_title']; ?></td>
						<td><?php echo $myrow['doc_desc']; ?></td>
						<?php if(empty($myrow['attachment1'])){ ?>
				<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment1']; ?>" target="_blank" />view file 1</a></td>
						<?php }?>
						
						<?php if(empty($myrow['attachment2'])){ ?>
				<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment2']; ?>" target="_blank" />view file 2</a></td>
						<?php }?>
						
						<td><?php echo $myrow['email_to']; ?></td>
<?php if(empty($myrow['flag']) || ($myrow['flag']==0)){ ?>
        				<td class="alert alert-warning">Response pending</td>
<?php } else if($myrow['flag']==1){?>
	<td class="alert alert-success">Documents Accepted</td><?php } else if ($myrow['flag']==2){?>
	
	<td class="alert alert-danger">Documents Rejected</td><?php }?>
	
 <td><a href="udocument.php?id=<?php echo $myrow['id'] ?>" class="btn btn-primary btn-xs">Update</a></td>
                                                 
	
               </tr>
	
		
		<?php
								}
				
								}
					
			
				
		?>
		
		</tbody>
		</table>
		</div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>

    <?php 
include('include/agent-footer.php');

 ?>