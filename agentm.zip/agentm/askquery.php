<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');
 ?>
<div class="contact">
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Ask Query</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Ask Query</li>
          </ol>
        </div>

      </div>
    </section>
	<?php
            if(isset($_POST['submit2']))
            {
                $sid=$_SESSION['agent_id'];
				
				$name=$_POST['name'];
                $email=$_POST['email'];
				$queryto=$_POST['queryto'];
				
                $msg=$_POST['msg'];
                if(isset($_FILES['file1']))
					{
						
						$img_name=strtolower($_FILES['file1']['name']);
						$tmp_name=$_FILES['file1']['tmp_name'];
						$ext=pathinfo($img_name,PATHINFO_EXTENSION);
						$compare=array('jpeg','jpg','txt','doc','xlsx','docx');
				if(isset($img_name))
					{
						if(!empty($img_name))
						{
							if(in_array($ext,$compare))
							{
					$path='docs/';
					if(file_exists($path.$img_name))
					{
						$l=3;
						$c='abcdefghijklmnopqrstuvwxyz';
						$img_name='';
						for($i=0;$i<=$l;$i++)
						{
							$img_name.=$c[rand(0,strlen($c))];
							}
							$img_name=$img_name.'.'.$ext;
					}
					if(move_uploaded_file($tmp_name,$path.$img_name))
					{
						$img_path=$path.$img_name;
						$strq="insert into query(cid,name,attachment,email,queryto,msg) values('$sid','$name','$img_path','$email','$queryto','$msg')";
			
                                    if(mysqli_query($connect,$strq))
        {
			                  
            echo '<div class="alert alert-success">Thanks for submitting your Query with document. </div>';
			
        }
        else
        {
            echo '<div class="alert alert-danger">Error AskQuery Page ' . $query .' <br>' . mysqli_error($connect).'</div>';
        }
					}
				}
				else
				{
					echo '<div class="alert alert-danger">Enter a valid attachment extension';
				}
			}
			else
				{
				$strq2="insert into query(cid,name,email,queryto,msg) values('$sid','$name','$email','$queryto','$msg')";
				
                                    if(mysqli_query($connect,$strq2))
								{
			                  
            echo '<div class="alert alert-success">Thanks for submitting your Query. </div>';
			
							}
        else
        {
            echo '<div class="alert alert-danger">Error in AskQuery Page ' . $query3 .' <br>' . mysqli_error($connect).'</div>';
        }
				}
		}
	}
	
	
						}
						
						?>
	
	<section id="contact" class="contact">
	<div class="container">
	
	

			<div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-md-12">
		  <div class="section-title" data-aos="fade-up">
          <h2>Ask Query</h2>
        </div>
		  
            
				<form method="post" action="askquery.php" enctype="multipart/form-data" class="modal-content">
				 <div class="form-row">
				<div class="col-md-6 form-group">
                  <input type="text" name="id" class="form-control" id="id" placeholder="Your ID" value="<?php echo $_SESSION['agent_id'];?>"  required disabled/>
                  
                </div>
					
				<div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" value="<?php echo $_SESSION['agent_name'];?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  
                </div>
               
				<div class="col-md-6 form-group">
                   <select name="queryto" id="queryto" class="form-control selectpicker" required onchange="GetEmail(this);">
                                                <option value="">Select Query To</option>
                                                <option value="Marketer">Marketer</option>
                                                <option value="Admin">Admin</option>
                                               
                                            </select> 
                </div>
				<div class="col-md-6 form-group">
                   <select name="email" id="email" class="form-control selectpicker" required>
                                                <option value="">Select Email</option>
                                                
                                               
                                            </select> 
                </div>
				 
				
				 </div> <div class="col-md-12 form-group">
                  <input type="file" name="file1" class="form-control" id="file1" placeholder="Attachment"  />
                  
                </div>
	<div class=" form-group">
				<textarea type="text"  class="form-control" required="required" onfocus="this.value = '';" name="msg" onblur="if (this.value == '') {this.value = 'Message...';}" required="">Type your Query</textarea>
				
				</div>
  <div class="text-center">
  
  
  <button type="submit" name="submit2" class="btn btn-info">Send Message</button></div>
					
						</form>
			</div>
			</div>
			
		
		</div>
	
	</section>
</div>

    <?php 
include('include/agent-footer.php');

 ?>
 <script>
 function GetEmail(elem){
		
	var br=$("#queryto").val();
		
		//alert(br);
		$("#email").load("loademail.php",{br:br});
	}
	</script>