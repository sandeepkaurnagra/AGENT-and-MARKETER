<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');
 ?>



 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Agent Panel</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Agent Panel</li>
          </ol>
        </div>

      </div>
    </section>


 <section id="cta-pricing" class="cta-pricing">
      <div class="container">

        <div class="text-center">
          
          
        </div>
<div class="row">
<div class="col-md-8" style="text-align:center;border:2px groove red;">

    <div class="text-center">
	<h3 style="margin-top:100px;">Welcome <?php echo  $_SESSION['agent_name'];?></h3>
          <h3><a href="adocument.php" >Click to Add Document Detail</a></h3>
          
        </div>
 

 
</div>
<div class="col-md-4" style="text-align:center">
<a href="askquery.php" >
 <img src="assets/img/enquiry.png"/>
 <p style="font-weight:bold;margin-top:20px;">Click Now for ask any Query</p>
 </a>
</div>
</div>
      </div>
    </section>


<?php 
include('include/agent-footer.php');
 ?>
