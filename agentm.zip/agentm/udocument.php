<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');
 ?>
<div class="contact">
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Update Uploaded Document</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Update Uploaded Document</li>
          </ol>
        </div>

      </div>
    </section>
	<?php
            if(isset($_POST['submit2']))
            {
                $agent_id=$_SESSION['agent_id'];
				$id=$_POST['id'];
				$name=$_POST['name'];
                $email=$_POST['email'];
				 $doc1=$_POST['doct'];
				
                $msg=$_POST['msg'];
			
				
                if(isset($_FILES['file1']) && isset($_FILES['file2']))
					{
						
						$img_name[1]=strtolower($_FILES['file1']['name']);
						$tmp_name[1]=$_FILES['file1']['tmp_name'];
						$ext[1]=pathinfo($img_name[1],PATHINFO_EXTENSION);
						
						
						$img_name[2]=strtolower($_FILES['file2']['name']);
						$tmp_name[2]=$_FILES['file2']['tmp_name'];
						$ext[2]=pathinfo($img_name[2],PATHINFO_EXTENSION);
						$flag=0;
						$compare=array('jpeg','jpg','txt','doc','xlsx','docx');
						
				if(isset($img_name[1]) && isset($img_name[2]) )
					{
						if(!empty($img_name[1]))
						{
							for($k=1;$k<=2;$k++)
								{
							if(in_array($ext[$k],$compare))
								{
					$path='docs/';
					if(file_exists($path.$img_name[$k]))
					{
						$l=3;
						$c='abcdefghijklmnopqrstuvwxyz';
						$img_name[$k]='';
						for($i=0;$i<=$l;$i++)
						{
							$img_name[$k].=$c[rand(0,strlen($c))];
							}
							$img_name[$k]=$img_name[$k].'.'.$ext[$k];
					}
					if(move_uploaded_file($tmp_name[$k],$path.$img_name[$k]))
					{
						$img_path[$k]=$path.$img_name[$k];
						$flag=1;
					
					}
					else
				{
					echo '<div class="alert alert-danger">Enter a valid attachment extension';
				}
			}
				}
			if($flag==1)
			{
				
				if(!empty($img_name[1]) && !empty($img_name[2]))
						{
							$imgquery2=mysqli_query($connect,"SELECT * FROM document WHERE id='$id'");
						$imgrow1=mysqli_fetch_array($imgquery2);
						$imgpath1=$imgrow1['attachment1'];
						$imgpath2=$imgrow1['attachment2'];
						unlink($imgpath1);
						unlink($imgpath2);
						$strq="update document set agent_id ='$agent_id',name='$name',doc_title='$doc1',doc_desc='$msg',attachment1='$img_path[1]',attachment2='$img_path[2]',email_to='$email',flag='0' where id='$id'";
			
                                    if(mysqli_query($connect,$strq))
        {
			                  
            echo '<div class="alert alert-success">Documents updated successfully with 2 uploaded files. </div>';
			header('Refresh:4;url=vdocument.php');	
        }
        else
        {
            echo '<div class="alert alert-danger">Error in Update Document Page ' . mysqli_error($connect).'</div>';
        }
					}
				
				else if(!empty($img_name[1]) && empty($img_name[2]))
				
				{
					$imgquery3=mysqli_query($connect,"SELECT * FROM document WHERE id='$id'");
						$imgrow3=mysqli_fetch_array($imgquery3);
						$imgpath3=$imgrow3['attachment1'];
						unlink($imgpath3);
				$strq2="update document set agent_id ='$agent_id',name='$name',doc_title='$doc1',doc_desc='$msg',attachment1='$img_path[1]',email_to='$email',flag='0' where id='$id'";
                                    if(mysqli_query($connect,$strq2))
								{
			                  
            echo '<div class="alert alert-success">Documents updated successfully with 1 uploaded files.</div>';
				header('Refresh:4;url=vdocument.php');
							}
        else
        {
            echo '<div class="alert alert-danger">Error in Update Document Page ' . mysqli_error($connect).'</div>';
        }
				}
				
		}
		
	}
	else
				{
				$strq3="update document set agent_id ='$agent_id',name='$name',doc_title='$doc1',doc_desc='$msg',email_to='$email',flag='0' where id='$id'";
                                    if(mysqli_query($connect,$strq3))
								{
			                  
            echo '<div class="alert alert-success">Documents data updated successfully.</div>';
			header('Refresh:4;url=vdocument.php');
							}
        else
        {
            echo '<div class="alert alert-danger">Error in Update Document Page ' . mysqli_error($connect).'</div>';
        }
				
				}
					}
					}
						}
						
						?>
	
	<section id="contact" class="contact">
	<div class="container">
	
	

			<div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-md-12">
		  <div class="section-title" data-aos="fade-up">
          <h2>Update Uploaded Document</h2>
        </div>
		   <?php
                            
if(isset($_GET['id']))
                          {
                            $id=$_GET['id'];
								$query=mysqli_query($connect,"select * from document where id='$id'");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
            
				<form method="post" action="udocument.php" enctype="multipart/form-data" class="modal-content">
				 <div class="form-row">
				 <input type="hidden" value="<?php echo $row['id']; ?>" name="id"/>
				<div class="col-md-6 form-group">
                  <input type="text" name="id" class="form-control" id="id" placeholder="Your ID" value="<?php echo $row['agent_id']; ?>"  required disabled/>
                  
                </div>
					
				<div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" value="<?php echo $row['name']; ?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  
                </div>
               <div class="col-md-6 form-group">
                  <input type="text" name="doct" class="form-control" id="doct" placeholder="Write Document Title" value="<?php echo $row['doc_title']; ?>"  data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  
                </div>
					<div class=" col-md-6  form-group">
				<textarea type="text"  class="form-control" rows="1"  required="required" onfocus="this.value = '';" name="msg" value="<?php echo $row['doc_desc']; ?>" onblur="if (this.value == '') {this.value = 'write Document Description here...';}" required=""><?php echo $row['doc_desc']; ?></textarea>
				
				</div>
				 <div class="col-md-6 form-group">
                  <input type="file" name="file1" class="form-control" id="file1"  placeholder="Attachment" onclick="GetEmail(this);"  />
                  
                </div>
				<div class="col-md-6 form-group">
                  <input type="file" name="file2" class="form-control" id="file2"  placeholder="Attachment"   />
                  
                </div>
				<input type="hidden" name="queryto" id="queryto" value="Marketer" />
				
				<div class="col-md-12 form-group">
                   <select name="email" id="email" class="form-control selectpicker" required">
				   <option value="<?php echo $row['email_to']; ?>"><?php echo $row['email_to']; ?></option>
                                              
                                                
                                               
                                            </select> 
                </div>
				 
				
				</div>
<?php
                                           }   
                                      }
						  }									  
                                      ?>
  <div class="text-center form-group">
  
  
  <button type="submit" name="submit2" class="btn btn-success">Upload Documents Now</button>
  </div>
					
						</form>
			</div>
			</div>
			
		
		</div>
	
	</section>
</div>

    <?php 
include('include/agent-footer.php');

 ?>
 <script>
 function GetEmail(elem){
		
	var br=$("#queryto").val();
		
		//alert(br);
		$("#email").load("loademail.php",{br:br});
	}
	</script>