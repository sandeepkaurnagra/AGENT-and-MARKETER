<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');


echo $br=$_POST['br'];

$query1=mysqli_query($connect,"SELECT * FROM agent_register WHERE id='".$_SESSION['agent_id']."'");
						$row2=mysqli_fetch_array($query1);
						$purpose=$row2['purpose'];
						if($br=='Marketer')
						{
						$query_login=mysqli_query($connect,"SELECT * FROM marketer_register WHERE purpose='$purpose'");
						if(mysqli_num_rows($query_login)>0)
                             {
								  while($row_login=mysqli_fetch_array($query_login))
                                    {
										 echo '<option value="'.$row_login['email'].' ">'.$row_login['username'].' - '.$row_login['email'].'</option>';
                        
										 }
                            }
                             else
                             {
								 echo '<option>No Marketer Linked with Agent</option>';
                                    }
						}
						else if($br=='Admin')
						{
							
							echo '<option value="admin - sumitkumarkatharia@gmail.com ">admin - sumitkumarkatharia@gmail.com</option>';
                            
						}
						
?>