﻿
 <?php ob_start();
 include('include/header.php');  
include('include/connection.php');  
?>
  <main id="main">
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Marketer Login</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>Marketer Login</li>
          </ol>
        </div>

      </div>
    </section>
	<?php 
                         if(isset($_POST['btn_client']))
                        {
							
                            $email_login=trim($_POST['username']);
                            $pass_login=trim($_POST['pass']);
                            $query_login=mysqli_query($connect, "select * from marketer_register where username='$email_login' and password='$pass_login'");
                            if(mysqli_num_rows($query_login)>0)
                             {
								  while($row_login=mysqli_fetch_array($query_login))
                                    {
										

                              $_SESSION['marketer_id']=$row_login['id'];  
                              $_SESSION['marketer_name']=$row_login['username'];  
                                 
                                echo '<script>
                                 alert("Marketer Login Successfully");
                                window.location.href="dash2.php";
                                </script>';                                 
                                //$url=$_SERVER['REQUEST_URI'];
                                header("refresh:1;Location: dash2.php"); 

			                    }
                            }
                             else
                             {
                                 echo '<script>
                                 alert("username and password mismatch.");
                                 </script>';
                            }
						}							
							
                        ?>
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

      
        <div class="row">
            <div class="modal-dialog col-md-6">
                <div class="modal-content">
                    <div class="modal-heading">
                        <h2 class="text-center">Marketer Login</h2>
                    </div>
                    <hr />
                    <div class="modal-body">
                        <form action="" method="post" role="form">
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <span class="icofont-user"></span>
                                    </span>
                                    <input type="text" class="form-control" placeholder="User Name" name="username" required/>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <span class="icofont-lock"></span>
                                    </span>
                                    <input type="password" class="form-control" placeholder="Password" name="pass" required/>

                                </div>

                            </div>

                            <div class="form-group text-center">
                                <button type="submit" name="btn_client" class="btn btn-link btn-success btn-lg">Login</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

      </div>
    </section><!-- End Services Section -->

    
  </main><!-- End #main -->

  <?php ob_start();
 include('include/footer.php');  

?>
 