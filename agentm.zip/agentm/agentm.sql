-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 04, 2020 at 03:49 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `agentm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `pass`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `agent_register`
--

CREATE TABLE `agent_register` (
  `id` int(255) NOT NULL auto_increment,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(500) NOT NULL,
  `contact` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `agent_register`
--

INSERT INTO `agent_register` (`id`, `fname`, `lname`, `purpose`, `username`, `password`, `email`, `contact`) VALUES
(1, 'sandeep1', 'kaur', 'Inter Official Use', 'sandeep', '1234', 'sandeep@gmail.com', '6985562233');

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `id` int(100) NOT NULL auto_increment,
  `agent_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `doc_title` varchar(100) NOT NULL,
  `doc_desc` text NOT NULL,
  `attachment1` varchar(100) NOT NULL,
  `attachment2` varchar(100) NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `response` text NOT NULL,
  `flag` int(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`id`, `agent_id`, `name`, `doc_title`, `doc_desc`, `attachment1`, `attachment2`, `email_to`, `response`, `flag`) VALUES
(10, 1, 'sandeep', 'aman', 'dhingra', 'docs/tybx.jpg', 'docs/lavi_sofiya.jpg', 'raj@gmail.com ', '', 1),
(11, 1, 'sandeep', 'aman', 'dhingra', 'docs/tybx.jpg', 'docs/lavi_sofiya.jpg', 'raj@gmail.com ', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `marketer_register`
--

CREATE TABLE `marketer_register` (
  `id` int(255) NOT NULL auto_increment,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(500) NOT NULL,
  `contact` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `marketer_register`
--

INSERT INTO `marketer_register` (`id`, `fname`, `lname`, `purpose`, `username`, `password`, `email`, `contact`) VALUES
(1, 'Raj', 'Man', 'Inter Official Use', 'rajmandeep', '123', 'raj@gmail.com', '6985562233');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `id` int(255) NOT NULL auto_increment,
  `cid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `attachment` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `queryto` varchar(255) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `response` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`id`, `cid`, `name`, `attachment`, `email`, `queryto`, `msg`, `response`) VALUES
(15, 1, 'sandeep', 'docs/gecd.jpg', 'raj@gmail.com ', 'Marketer', 'test', 'good work done');
