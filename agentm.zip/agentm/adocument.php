<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');
 ?>
<div class="contact">
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Upload Document</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Upload Document</li>
          </ol>
        </div>

      </div>
    </section>
	<?php
            if(isset($_POST['submit2']))
            {
                $agent_id=$_SESSION['agent_id'];
				
				$name=$_POST['name'];
                $email=$_POST['email'];
				 $doc1=$_POST['doct'];
				
				
                $msg=$_POST['msg'];
			
				
                if(isset($_FILES['file1']) && isset($_FILES['file2']))
					{
						
						$img_name[1]=strtolower($_FILES['file1']['name']);
						$tmp_name[1]=$_FILES['file1']['tmp_name'];
						$ext[1]=pathinfo($img_name[1],PATHINFO_EXTENSION);
						
						
						$img_name[2]=strtolower($_FILES['file2']['name']);
						$tmp_name[2]=$_FILES['file2']['tmp_name'];
						$ext[2]=pathinfo($img_name[2],PATHINFO_EXTENSION);
						$flag=0;
						$compare=array('jpeg','jpg','txt','doc','xlsx','docx');
						
				if(isset($img_name[1]) && isset($img_name[2]) )
					{
						if(!empty($img_name[1]))
						{
							for($k=1;$k<=2;$k++)
								{
							if(in_array($ext[$k],$compare))
								{
					$path='docs/';
					if(file_exists($path.$img_name[$k]))
					{
						$l=3;
						$c='abcdefghijklmnopqrstuvwxyz';
						$img_name[$k]='';
						for($i=0;$i<=$l;$i++)
						{
							$img_name[$k].=$c[rand(0,strlen($c))];
							}
							$img_name[$k]=$img_name[$k].'.'.$ext[$k];
					}
					if(move_uploaded_file($tmp_name[$k],$path.$img_name[$k]))
					{
						$img_path[$k]=$path.$img_name[$k];
						$flag=1;
					
					}
					else
				{
					echo '<div class="alert alert-danger">Enter a valid attachment extension';
				}
			}
				}
			if($flag==1)
			{
				if(!empty($img_name[1]) && !empty($img_name[2]))
						{
						$strq="insert into document(agent_id,name,doc_title,doc_desc,attachment1,attachment2,email_to,flag) values('$agent_id','$name','$doc1','$msg','$img_path[1]','$img_path[2]','$email','0')";
			
                                    if(mysqli_query($connect,$strq))
        {
			                  
            echo '<div class="alert alert-success">2 Files attached, Thanks for submitting your documents. </div>';
			
        }
        else
        {
            echo '<div class="alert alert-danger">Error Upload Document Page ' . mysqli_error($connect).'</div>';
        }
					}
				
				else if(!empty($img_name[1]) && empty($img_name[2]))
				
				{
				$strq2="insert into document(agent_id,name,doc_title,doc_desc,attachment1,email_to,flag) values('$agent_id','$name','$doc1','$msg','$img_path[1]','$email','0')";
                                    if(mysqli_query($connect,$strq2))
								{
			                  
            echo '<div class="alert alert-success">1 File attached, Thanks for submitting your documents. </div>';
			
							}
        else
        {
            echo '<div class="alert alert-danger">Error in Upload Document Page ' . mysqli_error($connect).'</div>';
        }
				}
		}
		else
				{
					echo '<div class="alert alert-danger">Attach documents first';
				}
	}
					}
					}
						}
						
						?>
	
	<section id="contact" class="contact">
	<div class="container">
	
	

			<div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-md-12">
		  <div class="section-title" data-aos="fade-up">
          <h2>Upload Document</h2>
        </div>
		  
            
				<form method="post" action="adocument.php" enctype="multipart/form-data" class="modal-content">
				 <div class="form-row">
				<div class="col-md-6 form-group">
                  <input type="text" name="id" class="form-control" id="id" placeholder="Your ID" value="<?php echo $_SESSION['agent_id'];?>"  required disabled/>
                  
                </div>
					
				<div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" value="<?php echo $_SESSION['agent_name'];?>" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  
                </div>
               <div class="col-md-6 form-group">
                  <input type="text" name="doct" class="form-control" id="doct" placeholder="Write Document Title"  data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  
                </div>
					<div class=" col-md-6  form-group">
				<textarea type="text"  class="form-control" rows="1"  required="required" onfocus="this.value = '';" name="msg" placeholder="write Document Description here..." required=""></textarea>
				
				</div>
				 <div class="col-md-6 form-group">
                  <input type="file" name="file1" class="form-control" id="file1"  placeholder="Attachment" onclick="GetEmail(this);" required />
                  
                </div>
				<div class="col-md-6 form-group">
                  <input type="file" name="file2" class="form-control" id="file2"  placeholder="Attachment"   />
                  
                </div>
				<input type="hidden" name="queryto" id="queryto" value="Marketer" />
				
				<div class="col-md-12 form-group">
                   <select name="email" id="email" class="form-control selectpicker" required">
                                                <option value="">Select Marketer Email</option>
                                                
                                               
                                            </select> 
                </div>
				 
				
				</div>

  <div class="text-center form-group">
  
  
  <button type="submit" name="submit2" class="btn btn-success">Upload Documents Now</button>
  </div>
					
						</form>
			</div>
			</div>
			
		
		</div>
	
	</section>
</div>

    <?php 
include('include/agent-footer.php');

 ?>
 <script>
 function GetEmail(elem){
		
	var br=$("#queryto").val();
		
		//alert(br);
		$("#email").load("loademail.php",{br:br});
	}
	</script>