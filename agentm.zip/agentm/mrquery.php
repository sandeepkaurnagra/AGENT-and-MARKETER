<?php ob_start();
include('include/marketer-header.php');
include('include/connection.php');
 ?>
 <div class="contact">
<section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Query Response</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Query Response</li>
          </ol>
        </div>

      </div>
    </section>
      
    
                      <?php
                        if(isset($_POST['submit']))
                        {
                            $name=$_POST['name'];
                           $id=$_POST['id'];
                            if(!empty($name))
                            {
                               
                                    $query=mysqli_query($connect,"update query set response='$name' where id='$id'");
                                    if(mysqli_affected_rows($connect))
                               {
							 echo '<script>
                                 alert("Agent Response Submitted");
                                window.location.href="squery.php";
                                </script>';                                 
                                //$url=$_SERVER['REQUEST_URI'];
                                header("refresh:1;Location: squery.php"); 
										}
										
else
{	
                               
                                echo '<script>
                                 alert("Error Occur");
                                window.location.href="squery.php";
                                </script>';                                 
                                //$url=$_SERVER['REQUEST_URI'];
                                header("refresh:1;Location: squery.php"); 
}
							}
						}
                      ?>
                          <section id="contact" class="contact">
	<div class="container">
	
	

			<div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-md-12">
		  <div class="section-title" data-aos="fade-up">
          <h2>Response Agent Queries</h2>
        </div>
		  
						 <?php
                            
if(isset($_GET['stuid']))
                          {
                            $id=$_GET['stuid'];
							$query=mysqli_query($connect,"select * from query where id='$id'");
                                      if(mysqli_num_rows($query)>0)
                                      {
                                           while($row=mysqli_fetch_array($query))
                                           {
                                                ?>
                              <form  role="form" method="post" action="mrquery.php">
							  <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
 <div class="form-group">
                                      <label for="class" class="col-lg-2 col-sm-2 control-label">Query</label>
                                      <div class="col-lg-10">
                                          <input required="required" type="text" class="form-control" value="<?php echo $row['msg']; ?> " name="query" disabled/>
                                      </div>
                                  </div>                                
								<div class="form-group">
                                      <label for="class" class="col-lg-2 col-sm-2 control-label">Response</label>
                                      <div class="col-lg-10">
                                          <input required="required" type="text" class="form-control" name="name"  placeholder="Response">
                                      </div>
                                  </div>
                               <?php
                                           }   
                                      }
						  }									  
                                      ?>
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-10">
                                          <input type="submit" name="submit" class="btn btn-danger" value="Submit" />
                                      </div>
                                  </div>
                              </form>
                          </div>
			</div>
			
		
		</div>
	
	</section>
</div>
      <!--main content end-->
<?php 
include('include/agent-footer.php');
 ?>