<?php ob_start();
include('include/marketer-header.php');
include('include/connection.php');
 ?>
 
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
        
          <h2>View Uploaded Documents</h2>
          <ol>
            <li><a href="dash2.php">Home</a></li>
            <li>View Uploaded Documents</li>
          </ol>
        </div>

      </div>
    </section>
 <!--Starting of Content-->
<section id="contact" class="contact">
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>View Uploaded Documents</h2>
        </div>
		  <?php
                            
if(isset($_GET['a']))
                          {
							  $id=$_GET['a'];
							  $strq3="update document set flag='1' where id='$id'";
                                    if(mysqli_query($connect,$strq3))
								{
			                  
            echo '<div class="alert alert-success">Documents Action Submitted successfully.</div>';
			header('Refresh:4;url=vmpdocument.php');
							}
        else
        {
            echo '<div class="alert alert-danger">Error in Action Submitted Document Page ' . mysqli_error($connect).'</div>';
        }
						  }
						  ?>
						  
						  <?php
                            
if(isset($_GET['r']))
                          {
							  
							   $id=$_GET['r'];
							  $strq4="update document set flag='2' where id='$id'";
                                    if(mysqli_query($connect,$strq4))
								{
			                  
            echo '<div class="alert alert-success">Documents Action Submitted successfully.</div>';
			header('Refresh:4;url=vmpdocument.php');
							}
        else
        {
            echo '<div class="alert alert-danger">Error in Action Submitted Document Page ' . mysqli_error($connect).'</div>';
        }
							  
						  }
						  ?>
			<table id="example" class="table table-striped table-bordered" style="width:100%">
	
<thead>
                	<tr><th>Agent ID</th>
<th>Name</th>
<th>Document Title</th>
					<th>Document Description</th>
					<th>Attachment 1</th>
						<th>Attachment 2</th>
					<th>Email to</th>
               
				  <th>Action1</th>
				  <th>Action2</th>
				  </tr></thead><tbody>
    			
		<?php
		
		$query1=mysqli_query($connect,"SELECT * FROM marketer_register WHERE id='".$_SESSION['marketer_id']."'");
						$row2=mysqli_fetch_array($query1);
						$purpose=$row2['email'];
		$query=mysqli_query($connect,"select  * from document where email_to='$purpose'  and flag='0'");
		
				           if(mysqli_num_rows($query)>0)
							{
								while($myrow=mysqli_fetch_array($query))
								{
							
		
				?>
			<tr>
                
    					<td><?php echo $myrow['agent_id']; ?></td>

        				<td><?php echo $myrow['name']; ?></td>
						<td><?php echo $myrow['doc_title']; ?></td>
						<td><?php echo $myrow['doc_desc']; ?></td>
						<?php if(empty($myrow['attachment1'])){ ?>
				<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment1']; ?>" target="_blank" />view file 1</a></td>
						<?php }?>
						
						<?php if(empty($myrow['attachment2'])){ ?>
				<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment2']; ?>" target="_blank" />view file 2</a></td>
						<?php }?>
						
						<td><?php echo $myrow['email_to']; ?></td>

	

 <td><a href="vmpdocument.php?a=<?php echo $myrow['id'] ?>" class="btn btn-success btn-xs">Accept</a></td>
 <td><a href="vmpdocument.php?r=<?php echo $myrow['id'] ?>" class="btn btn-danger btn-xs">Reject</a></td>
                                                
	
               </tr>
	
		
		<?php
								}
				
								}
					
			
				
		?>
		
		</tbody>
		</table>
		</div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>

    <?php 
include('include/agent-footer.php');

 ?>