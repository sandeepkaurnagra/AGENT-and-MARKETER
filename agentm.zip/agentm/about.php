﻿
 <?php ob_start();
 include('include/header.php');  
//include('include/connection.php');  
?>
  <main id="main">
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>About Project</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>About Project</li>
          </ol>
        </div>

      </div>
    </section>
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
<div class="col-md-12" style="background:#fff;">
  <div class="container">
  
<!-- <h1 style="margin-left:365px;">ASTS Library for Students</h1> -->


<section id="main-content1 " >
    <h1 style="text-align:center">Agent and Marketer</h1>
	<div class="col-lg-12">
            <h3 class="page-header"><i class="icofont-computer"></i> About Project</h3>
			<p style="font-size:18px;line-height:30px; text-align:justify">‘Agent and Marketer’ is a web based application to keep a record of documents provided by agent. Marketer and agent can login this web application by inputting credentials and can see the list of documents. Also, can request an agent to upload the remaining documents. Prior notification will be sent to the marketer when the agent will upload the documents. This web application assists the management team to track a record of all agents and marketer in form of reports.</p>
			</div>
</section>
 <h3 class="page-header" style="margin-top:20px;"><i class="icofont-users"></i> Project Team Members</h3>
<table class="table table-bordered table-hover">
<tbody>
<tr>
<th >
<strong>Member Name </strong>
</th>
<th >
<strong>Student ID </strong>
</th>
</tr>
<tr>
<td >
Sandeep Kaur(TL) 
</td>
<td >
1121107
</td>
</tr>
<tr>
<td >
Rajmandeep Khan Malik
</td>
<td >
1117798
</td>
</tr>
<tr>
<td >
Navneet Kaur Mann 	
</td>
<td >
1118545

</td>
</tr><tr>
<td >
Sanvir Singh	
</td>
<td >
1111080

</td>
</tr><tr>
<td >
Rana Partap Singh	
</td>
<td >
1118570
</td>
</tr>
</tbody>
</table>
	</div>
</div>


<!-- /.container -->
    </section><!-- End Services Section -->

    
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php ob_start();
 include('include/footer.php');  

?>
 