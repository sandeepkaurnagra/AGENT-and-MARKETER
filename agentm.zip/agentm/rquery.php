<?php ob_start();
include('include/agent-header.php');
include('include/connection.php');
 ?>
 
 <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Query Response</h2>
          <ol>
            <li><a href="dash.php">Home</a></li>
            <li>Query Response</li>
          </ol>
        </div>

      </div>
    </section>
 <!--Starting of Content-->
<section id="contact" class="contact">
	<div class="container">
	 <div class="section-title" data-aos="fade-up">
          <h2>Query Response</h2>
        </div>
		
			<div class="col-md-12 contact-grid wow fadeInUp animated" data-wow-delay=".5s">
			

		
                <table class="table table-bordered table-hover"><tbody>
                	<tr><th><strong>Agent ID</strong></th>
<th><strong>Name</strong></th>
<th><strong>Query To</strong></th>
					<th><strong>Email</strong></th>
					<th><strong>Attachment</strong></th>
					<th><strong>Query</strong></th>
                  <th><strong>Response</strong></th></tr>
    			
		<?php
		$query=mysqli_query($connect,"select  * from query where cid='".$_SESSION['agent_id']."'");
		
				           if(mysqli_num_rows($query)>0)
							{
								while($myrow=mysqli_fetch_array($query))
								{
							
		
				?>
			<tr>
                
    					<td><?php echo $myrow['cid']; ?></td>

        				<td><?php echo $myrow['name']; ?></td>
						<td><?php echo $myrow['queryto']; ?></td>
						<td><?php echo $myrow['email']; ?></td>
						<?php if(empty($myrow['attachment'])){ ?>
						<td class="text-center">-</td>
						<?php } else{?>
						<td><a href="<?php echo $myrow['attachment']; ?>" target="_blank" />view Attachment</a></td>
						<?php }?>
						<td><?php echo $myrow['msg']; ?></td>
<?php if(empty($myrow['response'])){ ?>
        				<td class="alert alert-warning">Not Respond Yet</td>
<?php } else{?>
	<td><?php echo $myrow['response'];  ?></td>

<?php }?>	
               </tr>
	
		
		<?php
		
				
								}
					
							}
			
				
		?>
		
		</tbody>
		</table>
		</div>
		
			<div class="clearfix"> </div>
		
		</div>
	</section>

    <?php 
include('include/agent-footer.php');

 ?>